// Ürün veri modeli sınıfı
// Gün 4: JSON yapısı ve model sınıfı oluşturma konusunun karşılığıdır.
// Fake Store API (https://fakestoreapi.com/products) yanıtına göre tasarlanmıştır.
class Product {
  final int id;
  final String title;
  final double price;
  final String description;
  final String category;
  final String image;
  final double rating;
  final int ratingCount;

  Product({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.category,
    required this.image,
    required this.rating,
    required this.ratingCount,
  });

  // JSON -> Dart nesnesi dönüşümü
  factory Product.fromJson(Map<String, dynamic> json) {
    final ratingJson = json['rating'] as Map<String, dynamic>?;
    return Product(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      price: (json['price'] is num) ? (json['price'] as num).toDouble() : 0.0,
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      image: json['image'] ?? '',
      rating: ratingJson != null
          ? (ratingJson['rate'] as num?)?.toDouble() ?? 0.0
          : 0.0,
      ratingCount: ratingJson != null ? (ratingJson['count'] ?? 0) : 0,
    );
  }

  // Dart nesnesi -> JSON dönüşümü
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'price': price,
      'description': description,
      'category': category,
      'image': image,
      'rating': {
        'rate': rating,
        'count': ratingCount,
      },
    };
  }
}
